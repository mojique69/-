﻿# -*- coding: utf-8 -*-

from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            image TEXT NOT NULL
        )
    ''')

    conn.execute('DELETE FROM posts')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    conn = get_db_connection()
    conn.execute('INSERT INTO posts (title, content, image) VALUES (?, ?, ?)', ('Рецепты', 'Здесь будут рецепты)', 'hamster1.jpg'))
    conn.execute('INSERT INTO posts (title, content, image) VALUES (?, ?, ?)', ('Самочувствие', 'Сюда писать самочувствие', 'hamster2.jpg'))
    posts = conn.execute('SELECT * FROM posts').fetchall()
    conn.close()
    return render_template('index.html', posts=posts)

@app.route('/<int:post_id>')
def get_post(post_id):
    conn = get_db_connection()
    conn.execute('INSERT INTO posts (title, content, image) VALUES (?, ?, ?)', ('Рецепты', 'Здесь будут рецепты)', 'hamster1.jpg'))
    conn.execute('INSERT INTO posts (title, content, image) VALUES (?, ?, ?)', ('Самочувствие', 'Сюда писать самочувствие', 'hamster2.jpg'))
    post = conn.execute('SELECT * FROM posts WHERE id = ?', (post_id,)).fetchone()
    conn.close()
    return render_template('post.html', post=post)

if __name__ == '__main__':
    init_db()
    app.run(port=5000)
